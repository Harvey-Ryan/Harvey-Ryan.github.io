function hide(element) {
    element.remove();
}

function logIn(element) {
    element.innerText = "Sign Out";
}